package Lab3Bai4;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<Student> danhsach = new ArrayList<>(Arrays.asList(
            new Student("101", "An", StudentType.INTERNATIONAL, 3.5),
            new Student("102", "Bình", StudentType.REGULAR, 2.8),
            new Student("103", "Chương", StudentType.PART_TIME, 3.9),
            new Student("104", "Dương", StudentType.INTERNATIONAL, 3.1),
            new Student("105", "Giang", StudentType.INTERNATIONAL, 3.8),
            new Student("106", "Hoàng", StudentType.PART_TIME, 2.5),
            new Student("107", "Khôi", StudentType.REGULAR, 3.7),
            new Student("108", "Linh", StudentType.PART_TIME, 3.3),
            new Student("109", "Minh", StudentType.INTERNATIONAL, 4.0),
            new Student("110", "Phương", StudentType.REGULAR, 3.0)
        ));

        System.out.println("Sinh viên International có Gpa >= 3.2");
        System.out.printf(" %-10s | %-15s | %-15s | %s\n", "ID", "Name", "Type", "GPA");
        danhsach.stream()
            .filter(s -> s.getType() == StudentType.INTERNATIONAL && s.getGpa() >= 3.2)
            .forEach(System.out::println);

        System.out.println("\nSắp xếp giảm dần theo GPA lấy top 3");
        danhsach.stream()
            .sorted(Comparator.comparing(Student::getGpa).reversed())
            .limit(3)
            .forEach(System.out::println);

        System.out.println("\nSinh viên Part_Time");
        List<String> sv_pt = danhsach.stream()
                                    .filter(s -> s.getType() == StudentType.PART_TIME)
                                    .map(Student::getName)
                                    .toList();
        sv_pt.forEach(System.out::println);
    }
}