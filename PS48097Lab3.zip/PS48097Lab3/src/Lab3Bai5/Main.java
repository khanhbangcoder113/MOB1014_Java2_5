package Lab3Bai5;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Student> danhsach = new ArrayList<>(Arrays.asList(
            new Student("SV001", "An", StudentType.INTERNATIONAL, 3.5),
            new Student("SV002", "Bình", StudentType.REGULAR, 2.8),
            new Student("SV003", "Chương", StudentType.PART_TIME, 3.9),
            new Student("SV004", "Dương", StudentType.INTERNATIONAL, 3.1),
            new Student("SV005", "Giang", StudentType.INTERNATIONAL, 3.8),
            new Student("SV006", "Hoàng", StudentType.PART_TIME, 2.5),
            new Student("SV007", "Khôi", StudentType.REGULAR, 3.7),
            new Student("SV008", "Linh", StudentType.PART_TIME, 3.3),
            new Student("SV009", "Minh", StudentType.INTERNATIONAL, 4.0),
            new Student("SV010", "Phương", StudentType.REGULAR, 3.0)
        ));

        Map<StudentType, Long> result = danhsach.stream()
                .collect(Collectors.groupingBy(
                    Student::getType,
                    Collectors.counting()
                ));

        System.out.println("Số lượng sinh viên theo từng loại:");
        result.forEach((t, u) -> 
            System.out.printf("%s: %d\n", t, u)
        );

        System.out.println("\nTính GPA trung bình theo từng loại:");
        Map<StudentType, Double> result1 = danhsach.stream()
                .collect(Collectors.groupingBy(Student::getType,
                        Collectors.averagingDouble(Student::getGpa)));
        result1.forEach(((t, u) -> 
            System.out.printf("%s: %.1f\n", t, u)
        ));

        System.out.println("\nSinh viên có GPA cao nhất");
        Optional<Student> maxGpa = danhsach.stream()
                .max(Comparator.comparing(Student::getGpa));

        System.out.printf("%-10s | %-15s | %-15s | %s\n", "ID", "Name", "Type", "GPA");
        System.out.println("----------------------------------------------------------");
        maxGpa.ifPresent(s -> 
            System.out.printf("%-10s | %-15s | %-15s | %.1f\n",
                    s.getId(), s.getName(), s.getType(), s.getGpa())
        );
    }
}