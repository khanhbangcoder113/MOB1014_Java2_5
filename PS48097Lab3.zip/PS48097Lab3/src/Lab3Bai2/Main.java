package Lab3Bai2

import java.util.*;
import java.util.stream.Collectors;

// 1. Tạo Class Employee
class Employee {
    String id, name;
    double salary;

    public Employee(String id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    @Override
    public String toString() {
        return id + " - " + name + " - " + salary;
    }
}

public class Lab3bai2 {
    public static void main(String[] args) {
        // 2. Tạo danh sách ít nhất 8 nhân viên
        List<Employee> list = new ArrayList<>();
        list.add(new Employee("NV01", "An", 12000000));
        list.add(new Employee("NV02", "Anh", 20000000));
        list.add(new Employee("NV03", "Bình", 16000000));
        list.add(new Employee("NV04", "Cường", 8000000));
        list.add(new Employee("NV05", "Dũng", 25000000));
        list.add(new Employee("NV06", "Ân", 18000000));
        list.add(new Employee("NV07", "Giang", 14000000));
        list.add(new Employee("NV08", "Hạnh", 30000000));

        // --- THỰC HIỆN BẰNG STREAM ---

        // + Lọc nhân viên có lương >= 15tr
        System.out.println("--- NV lương >= 15tr ---");
        list.stream()
            .filter(e -> e.salary >= 15000000)
            .forEach(System.out::println);

        // + Sắp xếp nhân viên theo lương giảm dần
        System.out.println("\n--- Sắp xếp lương giảm dần ---");
        list.stream()
            .sorted((e1, e2) -> Double.compare(e2.salary, e1.salary))
            .forEach(System.out::println);

        // + Lấy danh sách TÊN nhân viên (map)
        System.out.println("\n--- Danh sách chỉ gồm tên ---");
        List<String> namesOnly = list.stream()
                                     .map(e -> e.name)
                                     .collect(Collectors.toList());
        namesOnly.forEach(System.out::println);

        // + Đếm số NV có tên bắt đầu bằng chữ "A" (không phân biệt hoa thường)
        long count = list.stream()
                         .filter(e -> e.name.toUpperCase().startsWith("A"))
                         .count();
        System.out.println("\nSố nhân viên tên bắt đầu bằng chữ A: " + count);
    }
}