package Lab3Bai3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Lab3_Bai3_V2 {
    public static void main(String[] args) {
        List<Employee> nv = new ArrayList<>(Arrays.asList(
            new Employee("NV001", "Băng", 15000000),
            new Employee("NV002", "Hoàng", 12500000),
            new Employee("NV003", "Linh", 22000000),
            new Employee("NV004", "Tuấn", 18000000),
            new Employee("NV005", "Mai", 25000000),
            new Employee("NV006", "Hùng", 9000000),
            new Employee("NV007", "Lan", 15000000),
            new Employee("NV008", "Quốc", 25000000)
        ));

        double tong = nv.stream()
                        .mapToDouble(s -> s.getSalary())
                        .sum();
        System.out.printf("Tổng lương toàn công ty: %,.0f VNĐ\n", tong);
        System.out.printf("Lương trung bình: %,.0f VNĐ\n", (tong / nv.size()));

        Employee max = nv.stream()
                        .max(Comparator.comparing(Employee::getSalary))
                        .orElse(null);

        System.out.println("\n--- Nhân viên có lương cao nhất ---");
        if (max != null) {
            nv.stream()
              .filter(s -> s.getSalary() == max.getSalary())
              .limit(1)
              .forEach(System.out::println);
        }
    }
}