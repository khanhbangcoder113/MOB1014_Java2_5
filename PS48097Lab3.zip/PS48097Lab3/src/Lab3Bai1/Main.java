package Lab3Bai1;

	import java.util.ArrayList;
	import java.util.Arrays;
	import java.util.Collections;

	public class Lab3bai1 {
	    public static void main(String[] args) {
	        ArrayList<String> dsTen = new ArrayList<>(Arrays.asList(
	            "An", "Bình", "Chương", "Dương", "Giang", 
	            "Hoàng", "Khôi", "Linh", "Minh", "Phương"
	        ));

	        System.out.println("--- Toàn bộ danh sách ---");
	        dsTen.forEach(ten -> System.out.println(ten));

	        System.out.println("\n--- Các tên có độ dài > 5 ---");
	        dsTen.forEach(ten -> {
	            if (ten.length() > 5) System.out.println(ten);
	        });

	        System.out.println("\n--- Sắp xếp A-Z ---");
	        dsTen.sort((a, b) -> a.compareTo(b));
	        dsTen.forEach(ten -> System.out.println(ten));

	        System.out.println("\n--- Sắp xếp theo độ dài ---");
	        dsTen.sort((a, b) -> a.length() - b.length());
	        dsTen.forEach(ten -> System.out.println(ten));
	    }
	}

