package Lab4Bai4;

public class Main {
    public static void main(String[] args) {
        GenericManager<Student> list = new GenericManager<>();

        System.out.println("--- Kiểm tra danh sách rỗng ---");
        try {
            System.out.println("Cố gắng lấy phần tử đầu: " + list.getFirst());
        } catch (EmptyListException e) {
            System.err.println("Thông báo: " + e.getMessage());
        }

        System.out.println("\n--- Thêm dữ liệu vào danh sách ---");
        list.add(new Student("B01", "Thanh Hằng", 4.0));
        list.add(new Student("B02", "Quốc Bảo", 3.5));
        list.add(new Student("B03", "Minh Thư", 3.9));

        System.out.println("Dữ liệu hiện có:");
        list.display();

        System.out.println("\n--- Truy xuất phần tử đầu & cuối ---");
        try {
            Student first = list.getFirst();
            Student last = list.getLast();
            
            System.out.println(">> Sinh viên đầu tiên: " + first);
            System.out.println(">> Sinh viên cuối cùng: " + last);
        } catch (EmptyListException e) {
            System.out.println("Lỗi bất ngờ: " + e.getMessage());
        }
    }
}