package Lab4Bai2;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        EmployeeService manager = new EmployeeService();
        
        while(true) {
            try {
                Employee emp = new Employee();
                System.out.println(">> Nhập thông tin nhân sự mới:");
                
                System.out.print("- Mã NV: ");
                emp.setId(sc.nextLine().toUpperCase().trim());
                
                System.out.print("- Họ tên: ");
                emp.setName(sc.nextLine().trim());
                
                System.out.print("- Mức lương: ");
                emp.setSalary(Double.parseDouble(sc.nextLine()));
                
                manager.inputEmployee(emp);
                System.out.println(" Đã lưu thông tin thành công.");
                
            } catch (InvalidSalaryException e) {
                System.out.println("Lỗi nghiệp vụ: " + e.getMessage());
            } catch (NumberFormatException e) {
                System.out.println("Lỗi định dạng: Lương phải là một con số!");
            } catch (Exception e) {
                System.out.println("Lỗi hệ thống: " + e.getMessage());
            }
            
            System.out.print("Tiếp tục nhập thêm nhân viên khác? (Y/N): ");
            if(sc.nextLine().trim().equalsIgnoreCase("n")) break;
        }
        
        System.out.println("\n" + "=".repeat(20));
        System.out.println("TỔNG KẾT DANH SÁCH NHÂN VIÊN");
        manager.printEmployee();
        
        sc.close();
    }
}