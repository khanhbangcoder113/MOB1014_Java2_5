package Lab4Bai1;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int choice;
        StudentService service = new StudentService();
        
        do {
            System.out.println("========= QUẢN LÝ HỒ SƠ SINH VIÊN =========");
            System.out.println("1. Thêm mới sinh viên");
            System.out.println("2. Hiển thị danh sách");
            System.out.println("0. Kết thúc");
            
            while(true) {
                try {
                    System.out.print("Lựa chọn của bạn: ");
                    choice = sc.nextInt();
                    sc.nextLine(); 
                    break;
                } catch (Exception e) {
                    System.out.println("⚠️ Lỗi: Vui lòng chỉ nhập chữ số!");
                    sc.nextLine();
                }
            }
            
            switch(choice) {
                case 1: 
                    System.out.println("--- Nhập liệu ---");
                    service.inputStudent(sc);
                    break;
                case 2: 
                    System.out.println("--- Danh sách hiện tại ---");
                    service.printStudent();
                    break;
                case 0: 
                    System.out.println("Hệ thống đang đóng. Tạm biệt!");
                    break;
                default:
                    System.out.println("Tính năng không tồn tại, vui lòng chọn lại.");
            }
            
            if (choice != 0) {
                System.out.print("\nNhấn phím 1 để tiếp tục quay lại Menu chính: ");
                int repeat;
                do {
                    repeat = sc.nextInt();
                    sc.nextLine();
                    if (repeat != 1) System.out.println("Nhập sai, hãy nhấn 1 để quay lại.");
                } while (repeat != 1);
            }
        
            for(int i = 0; i < 30; i++) System.out.println();
            
        } while(choice != 0);
        sc.close();
    }
}