package Lab4Bai3;

public class Main {
    public static void main(String[] args) {
    
        GenericManager<Student> studentList = new GenericManager<>();
        studentList.add(new Student("SV001", "Trần Anh Tuấn", 3.8));
        studentList.add(new Student("SV002", "Lê Thị Hồng", 3.2));
        studentList.add(new Student("SV003", "Nguyễn Minh Triết", 2.9));

        System.out.println("===== BẢNG ĐIỂM SINH VIÊN =====");
        System.out.printf("| %-8s | %-18s | %-5s |\n", "MSSV", "Họ và Tên", "GPA");
        System.out.println("-".repeat(42));
        studentList.display();
        
        System.out.println("\n\n"); 

        GenericManager<Employee> staffList = new GenericManager<>();
        staffList.add(new Employee("NV-99", "Phạm Văn Đồng", 15500));
        staffList.add(new Employee("NV-10", "Hoàng Thanh Vân", 22000));
        staffList.add(new Employee("NV-05", "Đỗ Bảo Nam", 18000));

        System.out.println("===== DANH SÁCH BẢNG LƯƠNG =====");
        System.out.printf("| %-8s | %-18s | %-10s |\n", "Mã NV", "Tên Nhân Viên", "Lương");
        System.out.println("-".repeat(45));
        staffList.display();
    }
}