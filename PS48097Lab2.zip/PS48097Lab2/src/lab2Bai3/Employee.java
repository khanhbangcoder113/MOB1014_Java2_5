package lab2Bai3;

public class Employee {
	private String iD;
	private String name;
	private double salary;
	
	public Employee(String iD, String name, double salary) {
		super();
		this.iD = iD;
		this.name = name;
		this.salary = salary;
	}

	public Employee() {
	}

	public String getiD() {
		return iD;
	}

	public void setiD(String iD) {
		this.iD = iD;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [iD=" + iD + ", name=" + name + ", salary=" + salary + "]";
	}
	
}
