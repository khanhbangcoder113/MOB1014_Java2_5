package lab2Bai1;
import java.util.ArrayList;

enum StudentType {
    REGULAR,
    PART_TIME,
    INTERNATIONAL;
}

class Student {
    private String iD;
    private String name;
    private StudentType Type;

    public Student(String iD, String name, StudentType type) {
        this.iD = iD;
        this.name = name;
        this.Type = type;
    }

    public String getiD() { return iD; }
    public String getName() { return name; }
    public StudentType getType() { return Type; }

    @Override
    public String toString() {
        return this.iD + " - " + this.name + " [" + this.Type + "]";
    }
}

public class Main {
    public static void main(String[] args) {
        ArrayList<Student> st = new ArrayList<>();
        
        st.add(new Student("SV01", "An", StudentType.REGULAR));
        st.add(new Student("SV02", "Binh", StudentType.REGULAR));
        st.add(new Student("SV03", "Cuong", StudentType.PART_TIME));
        st.add(new Student("SV04", "Dung", StudentType.PART_TIME));
        st.add(new Student("SV05", "Em", StudentType.INTERNATIONAL));
        st.add(new Student("SV06", "Giang", StudentType.INTERNATIONAL));

        System.out.println("Danh sach sinh vien:");
        for (Student student : st) {
            System.out.println(student);
        }
		
        int countREGULAR = 0;
        int countPART_TIME = 0;
        int countINTERNATIONAL = 0;

        for (Student students : st) {
            if (students.getType() == StudentType.REGULAR) {
                countREGULAR++;
            } else {
                if (students.getType() == StudentType.PART_TIME) {
                    countPART_TIME++;
                } else {
                    countINTERNATIONAL++;
                }
            }
        }

        System.out.println("\nThong ke:");
        System.out.println("REGULAR: " + countREGULAR);
        System.out.println("PART_TIME: " + countPART_TIME);
        System.out.println("INTERNATIONAL: " + countINTERNATIONAL);
    }
}