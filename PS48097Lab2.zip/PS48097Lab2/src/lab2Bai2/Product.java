package lab2Bai2;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

enum ProductCategory {
    FOOD,
    ELECTRONIC,
    CLOTHING;
}

public class Product {
    private String iD;
    private String name;
    private double price;
    private ProductCategory category;

    public Product(String iD, String name, double price, ProductCategory category) {
        this.iD = iD;
        this.name = name;
        this.price = price;
        this.category = category;
    }

    public String getiD() { return iD; }
    public void setiD(String iD) { this.iD = iD; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }
    public ProductCategory getCategory() { return category; }
    public void setCategory(ProductCategory category) { this.category = category; }

    @Override
    public String toString() {
        return "ID: " + iD + " | Ten: " + name + " | Gia: " + price + " | Loai: " + category;
    }

    public static void main(String[] args) {
        ArrayList<Product> p = new ArrayList<Product>();
     
        p.add(new Product("SP01", "Banh Ngot", 25000, ProductCategory.FOOD));
        p.add(new Product("SP02", "Nuoc Ep", 30000, ProductCategory.FOOD));
        p.add(new Product("SP03", "Ga Ran", 45000, ProductCategory.FOOD));
        
        p.add(new Product("SP04", "Ban Phim", 550000, ProductCategory.ELECTRONIC));
        p.add(new Product("SP05", "Tai Nghe", 1200000, ProductCategory.ELECTRONIC));
        
        p.add(new Product("SP06", "Ao Thun", 180000, ProductCategory.CLOTHING));
        p.add(new Product("SP07", "Quan Short", 220000, ProductCategory.CLOTHING));
        p.add(new Product("SP08", "Mu Luoi Trai", 95000, ProductCategory.CLOTHING));

        System.out.println("--- DANH SACH SAN PHAM ---");
        for (Product product : p) {
            System.out.println(product);
        }

        Map<ProductCategory, Integer> mapCount = new HashMap<ProductCategory, Integer>();
        for (Product product : p) {
            ProductCategory pro = product.getCategory();
            if (mapCount.containsKey(pro)) {
                mapCount.put(pro, mapCount.get(pro) + 1);
            } else {
                mapCount.put(pro, 1);
            }
        }
        
        System.out.println("\n--- SO LUONG THEO LOAI ---");
        for (ProductCategory pc : mapCount.keySet()) {
            System.out.println(pc + ": " + mapCount.get(pc));
        }

        Map<ProductCategory, Double> mapPrice = new HashMap<ProductCategory, Double>();
        for (Product product : p) {
            ProductCategory pro = product.getCategory();
            if (mapPrice.containsKey(pro)) {
                mapPrice.put(pro, mapPrice.get(pro) + product.getPrice());
            } else {
                mapPrice.put(pro, product.getPrice());
            }
        }
        
        System.out.println("\n--- TONG TIEN THEO LOAI ---");
        for (ProductCategory cat : mapPrice.keySet()) {
            System.out.println(cat + ": " + mapPrice.get(cat));
        }
    }
}